"""Local development server. Production uses a WSGI server or PHP gateway."""
import argparse
import os
from socketserver import ThreadingMixIn
from wsgiref.simple_server import WSGIServer, make_server
from ecoloop.config import load_env, ROOT
from ecoloop.store import JsonStore
from ecoloop.web import create_application


class ThreadedServer(ThreadingMixIn, WSGIServer):
    daemon_threads = True


def main():
    parser = argparse.ArgumentParser(description='Run EcoLoop locally')
    parser.add_argument('--demo', action='store_true', help='Use isolated sample data and the demo account switcher')
    parser.add_argument('--host')
    parser.add_argument('--port', type=int)
    args = parser.parse_args()
    load_env()
    if args.demo:
        if os.getenv('APP_ENV') == 'production':
            parser.error('Demo mode is disabled in production.')
        os.environ['DEMO_MODE'] = '1'
        os.environ['DATA_PATH'] = str(ROOT / 'storage/demo.json')
        os.environ['UPLOAD_DIR'] = str(ROOT / 'storage/demo-uploads')
        from ecoloop.seed import seed_demo
        with JsonStore(os.environ['DATA_PATH']).transaction() as data:
            seed_demo(data)
    app = create_application()
    host = args.host or os.getenv('HOST', '127.0.0.1')
    port = args.port if args.port is not None else int(os.getenv('PORT', '3000'))
    with make_server(host, port, app, server_class=ThreadedServer) as server:
        print(f'EcoLoop is ready at http://{host}:{server.server_port}', flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
