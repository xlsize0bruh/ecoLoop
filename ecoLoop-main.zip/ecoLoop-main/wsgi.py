"""Production WSGI entry point: gunicorn wsgi:application."""
from ecoloop.web import create_application

application = create_application()
